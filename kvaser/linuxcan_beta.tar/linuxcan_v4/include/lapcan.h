#ifndef     __HEADERFILE_LAPCAN_LOADED
#define     __HEADERFILE_LAPCAN_LOADED

/*
** Copyright 2002-2006 KVASER AB, Sweden.  All rights reserved.
*/

extern void lapprint(int n);

#endif    /* __HEADERFILE_LAPCAN_LOADED **/

